package com.teampicker;

import net.minecraftforge.common.ForgeConfigSpec;

/** config/teampicker-common.toml 로 저장되는 설정. 서버 쪽 값이 사용된다. */
public final class PickerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue DISTANCE;
    public static final ForgeConfigSpec.IntValue SEARCH_RADIUS;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        DISTANCE = builder
                .comment("게임 시작 시 월드 중심(0, 0)에서 각 팀이 이동할 거리(블록).",
                        "빨강팀은 +X 방향, 파랑팀은 -X 방향으로 이만큼 떨어진 곳으로 갑니다.")
                .defineInRange("distance", 10000, 100, 29000000);
        SEARCH_RADIUS = builder
                .comment("목표 지점이 바다/강이면, 이 반경(블록) 안에서 가장 가까운 육지를 찾아 대신 보냅니다.",
                        "0 으로 하면 육지를 찾지 않고 목표 지점으로 그대로 보냅니다.")
                .defineInRange("land_search_radius", 3000, 0, 20000);
        SPEC = builder.build();
    }

    private PickerConfig() {}
}
