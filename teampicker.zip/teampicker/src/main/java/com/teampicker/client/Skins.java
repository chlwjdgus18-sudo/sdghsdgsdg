package com.teampicker.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

final class Skins {
    private Skins() {}

    static ResourceLocation of(UUID id) {
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        PlayerInfo info = conn == null ? null : conn.getPlayerInfo(id);
        return info != null ? info.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(id);
    }

    /** 스킨 이미지(64x64)에서 얼굴(8,8)과 모자 레이어(40,8)를 잘라 머리를 그린다. */
    static void drawHead(GuiGraphics g, UUID id, int x, int y, int size) {
        ResourceLocation skin = of(id);
        RenderSystem.enableBlend();
        g.blit(skin, x, y, size, size, 8.0F, 8.0F, 8, 8, 64, 64);
        g.blit(skin, x, y, size, size, 40.0F, 8.0F, 8, 8, 64, 64);
        RenderSystem.disableBlend();
    }
}
