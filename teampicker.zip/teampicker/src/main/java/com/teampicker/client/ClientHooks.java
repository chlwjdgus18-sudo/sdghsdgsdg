package com.teampicker.client;

import com.teampicker.network.OpenPickerPacket;
import net.minecraft.client.Minecraft;

import java.util.List;

/** 서버에서 온 패킷이 클라이언트 화면을 열 때만 쓰는 진입점 (서버에서 로드되지 않도록 분리). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openPicker(List<OpenPickerPacket.Entry> entries) {
        Minecraft.getInstance().setScreen(new PlayerListScreen(entries));
    }
}
