package com.teampicker;

import com.teampicker.network.Network;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(TeamPickerMod.MODID)
public class TeamPickerMod {
    public static final String MODID = "teampicker";

    public TeamPickerMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PickerConfig.SPEC);
        Network.register();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        PickerCommand.register(event.getDispatcher());
    }
}
