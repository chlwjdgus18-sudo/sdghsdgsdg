package com.teampicker.network;

import com.teampicker.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/** 서버 -> 클라이언트: 접속자 목록을 전달하고 UI를 연다. */
public record OpenPickerPacket(List<Entry> entries) {

    public record Entry(UUID id, String name, String team) {}

    public static void encode(OpenPickerPacket pkt, FriendlyByteBuf buf) {
        buf.writeVarInt(pkt.entries.size());
        for (Entry e : pkt.entries) {
            buf.writeUUID(e.id());
            buf.writeUtf(e.name(), 64);
            buf.writeUtf(e.team(), 64);
        }
    }

    public static OpenPickerPacket decode(FriendlyByteBuf buf) {
        int size = buf.readVarInt();
        List<Entry> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(new Entry(buf.readUUID(), buf.readUtf(64), buf.readUtf(64)));
        }
        return new OpenPickerPacket(list);
    }

    public static void handle(OpenPickerPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openPicker(pkt.entries())));
        c.setPacketHandled(true);
    }
}
