package com.teampicker.network;

import com.teampicker.PickerConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.util.ArrayList;

/** 빨강/파랑 팀원을 각자 멀리 떨어진 육지로 보내고, 그 자리를 리스폰 지점으로 지정한다. */
public final class GameStarter {
    /** 육지를 찾을 때 한 번에 건너뛰는 간격(블록). */
    private static final int SEARCH_STEP = 64;

    private GameStarter() {}

    public static void start(ServerPlayer sender) {
        MinecraftServer server = sender.server;
        ServerLevel overworld = server.overworld();
        Scoreboard scoreboard = server.getScoreboard();

        int distance = PickerConfig.DISTANCE.get();
        int radius = PickerConfig.SEARCH_RADIUS.get();

        BlockPos redPos = findLand(overworld, distance, 0, radius);
        BlockPos bluePos = findLand(overworld, -distance, 0, radius);

        // 반경 안에서 육지를 못 찾으면 원래 목표 지점으로 보낸다
        boolean redFound = redPos != null;
        boolean blueFound = bluePos != null;
        if (redPos == null) {
            redPos = surface(overworld, distance, 0);
        }
        if (bluePos == null) {
            bluePos = surface(overworld, -distance, 0);
        }

        int red = 0;
        int blue = 0;

        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            PlayerTeam team = scoreboard.getPlayersTeam(p.getScoreboardName());
            if (team == null) {
                continue;
            }

            BlockPos pos;
            if (team.getName().equals("red")) {
                pos = redPos;
                red++;
            } else if (team.getName().equals("blue")) {
                pos = bluePos;
                blue++;
            } else {
                continue;
            }

            // forced = true : 침대 없이도 이 좌표가 리스폰 지점이 된다
            p.setRespawnPosition(Level.OVERWORLD, pos, 0.0F, true, false);
            p.teleportTo(overworld, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.getYRot(), p.getXRot());
            p.sendSystemMessage(Component.literal("게임 시작!").withStyle(ChatFormatting.GOLD));
        }

        if (red + blue == 0) {
            sender.sendSystemMessage(Component.literal("빨강/파랑 팀에 아무도 없어서 아무도 이동하지 않았습니다."));
        } else {
            sender.sendSystemMessage(Component.literal(
                    "게임 시작: 빨강 " + red + "명 → X=" + redPos.getX() + ", Z=" + redPos.getZ()
                            + " / 파랑 " + blue + "명 → X=" + bluePos.getX() + ", Z=" + bluePos.getZ()));
            if (!redFound || !blueFound) {
                sender.sendSystemMessage(Component.literal(
                                "반경 안에서 육지를 찾지 못한 팀이 있어 원래 좌표로 보냈습니다. 바다일 수 있어요.")
                        .withStyle(ChatFormatting.RED));
            }
        }
    }

    /**
     * 목표 (cx, cz) 에서 가까운 순서(안쪽 고리부터 바깥쪽 고리)로 육지를 찾는다.
     * 바이옴은 청크를 생성하지 않고 싸게 확인할 수 있으므로, 바다/강이 아닌 곳만 골라서
     * 실제로 청크를 생성해 바닥이 안전한지 확인한다. 못 찾으면 null.
     */
    private static BlockPos findLand(ServerLevel level, int cx, int cz, int maxRadius) {
        int seaLevel = level.getSeaLevel();

        for (int r = 0; r <= maxRadius; r += SEARCH_STEP) {
            for (int dx = -r; dx <= r; dx += SEARCH_STEP) {
                for (int dz = -r; dz <= r; dz += SEARCH_STEP) {
                    // 이번 고리(테두리)에 해당하는 점만 검사
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
                        continue;
                    }

                    int x = cx + dx;
                    int z = cz + dz;

                    Holder<Biome> biome = level.getBiome(new BlockPos(x, seaLevel, z));
                    if (biome.is(BiomeTags.IS_OCEAN) || biome.is(BiomeTags.IS_RIVER)) {
                        continue;
                    }

                    BlockPos ground = surface(level, x, z);
                    if (isSafe(level, ground)) {
                        return ground;
                    }
                }
            }
        }
        return null;
    }

    /** 서 있을 자리 바로 아래 블록이 물/용암/허공/위험 블록이 아닌지 확인한다. */
    private static boolean isSafe(ServerLevel level, BlockPos pos) {
        BlockState below = level.getBlockState(pos.below());
        if (!below.getFluidState().isEmpty()) {
            return false; // 물, 용암
        }
        if (below.isAir()) {
            return false;
        }
        return !(below.is(Blocks.MAGMA_BLOCK) || below.is(Blocks.CACTUS) || below.is(Blocks.FIRE));
    }

    /** 해당 X, Z 지점의 지면 위 좌표를 구한다. 청크를 먼저 생성/로드한다. */
    private static BlockPos surface(ServerLevel level, int x, int z) {
        level.getChunk(x >> 4, z >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        return new BlockPos(x, y, z);
    }
}
