package com.teampicker.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 클라이언트 -> 서버: 게임 시작 요청 (내용 없음). */
public record StartGamePacket() {

    public static void encode(StartGamePacket pkt, FriendlyByteBuf buf) {
        // 보낼 데이터 없음
    }

    public static StartGamePacket decode(FriendlyByteBuf buf) {
        return new StartGamePacket();
    }

    public static void handle(StartGamePacket pkt, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sender = c.getSender();
            // 서버에서 OP 권한을 다시 검증
            if (sender == null || !sender.hasPermissions(2)) {
                return;
            }
            GameStarter.start(sender);
        });
        c.setPacketHandled(true);
    }
}
